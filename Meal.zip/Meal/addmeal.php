<?php
include("Config.php");
   session_start();
   if($_SERVER["REQUEST_METHOD"] == "POST") 
   {
      $myusername = $_SESSION['myusername']; 
	  $mydate = mysqli_real_escape_string($db,$_POST['date']);
	  $mybfast = mysqli_real_escape_string($db,$_POST['bfast']);
	  $myluns = mysqli_real_escape_string($db,$_POST['luns']);
	  $mydnr = mysqli_real_escape_string($db,$_POST['dnr']);
	  $mytotal = $mybfast+$myluns+$mydnr;
	  $sql = "SELECT * FROM member WHERE username = '$myusername'";
	   $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $active = $row['active'];
     
      $count = mysqli_num_rows($result);
      
      
		
      if($count == 1) {
         
         
         $sql = "INSERT INTO meal (Date,username,bfast,luns,dnr,tmeal)VALUES ('$mydate', '$myusername','$mybfast','$myluns','$mydnr','$mytotal')"; 
	 
	    if ($db->query($sql) === TRUE)
		 {
       header("location: Memberpage.php");
        }  
 else {
    echo "Error: " . $sql . "<br>" . $conn->error;
     }
	  
      }else
	   {
         echo "Your User Name is Not Registers";
      }
   }
	 
?>
<!DOCTYPE html >
<html >
<head>
<link rel="stylesheet" href="style.css">
<title>Untitled Document</title>
</head>

<body bgcolor="#006666">
<h1 align="center" >Meal Mangment  System</h1>
<ul>
<li><a href="Memberpage.php"><h3>My Page</h3></a></li>
<li><a href="personal.php"><h3> Show My Info</h3></a></li>
 <li><a href="addmeal.php"><h3>Next Day Meal</h3></a></li>
 <li><a href="Showdate.php"><h3>Show My Bazzer Date</h3></a></li>
 <li><a href="Logout.php"><h3>Logout</h3></a></li>
 </ul>
<p>Welcome <?php echo $_SESSION['myusername']; ?>!</p>
<h2 align="center">Given Meal</h2><br>
 <form align="center" action = "" method = "post">
               
                  <label>Date  :</label><input type = "Date" name = "date" class = "box" required/><br/><br />
				  <label>BreakFrst  :</label><select name="bfast">
				  <option value="0">0</option>
         <option value="1">1</option>
         <option value="2">2</option>
         <option value="3">3</option>
        <option value="4">4</option>
        </select><br /><br />
				  <label>Lunace  :</label><select name="luns">
				  <option value="0">0</option>
        <option value="1">1</option>
        <option value="2">2</option>
        <option value="3">3</option>
        <option value="4">4</option>
          </select><br /><br />
				  <label>Dinar  :</label><select name="dnr">
				  <option value="0">0</option>
         <option value="1">1</option>
         <option value="2">2</option>
           <option value="3">3</option>
       <option value="4">4</option>
       </select><br /><br />
				  
                  <input type = "submit" value = " Submit "/><br />
               </form>
</body>
</html>

