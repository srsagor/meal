<?php
include("Config.php");
   session_start();
   if($_SERVER["REQUEST_METHOD"] == "POST") 
   {
      $myusername = mysqli_real_escape_string($db,$_POST['username']); 
	  $mydate1 = mysqli_real_escape_string($db,$_POST['date1']);
	  $mydate2 = mysqli_real_escape_string($db,$_POST['date2']);
	  $mydate3 = mysqli_real_escape_string($db,$_POST['date3']);
	  $sql = "SELECT * FROM member WHERE username = '$myusername'";
	   $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $active = $row['active'];
     
      $count = mysqli_num_rows($result);
      
     
		
      if($count == 1) {
	 $sql = "INSERT INTO Blist (username,Date1,Date2,Date3)VALUES ('$myusername', '$mydate1','$mydate2','$mydate3')"; 
	 
	 if ($db->query($sql) === TRUE) {
    header("location: mangerpage.php");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
}
 else
	   {
         echo "Your User Name is Not Registers";
      }	  
}

?>
<!DOCTYPE html >
<html >
<head>
<link rel="stylesheet" href="style.css">
<title>Untitled Document</title>
</head>

<body bgcolor="#006699">
<h1 align="center" >Meal Mangment  System</h1>
<ul>
<li><a href="mangerpage.php"><h3> My Page</h3></a></li>
<li><a href="bazzercost.php"><h3> Add Bazzar Cost</h3></a></li>
<li><a href="Deposit.php"><h3> Deposit</h3></a></li>
<li><a href="addbazzerdate.php"><h3> Add Bazzer Date</h3></a></li>
<li><a href="showalldate.php"><h3> Show Bazzer Date</h3></a></li>
<li><a href="Logout.php"><h3>Logout</h3></a></li>
</ul>
<h2>Welcome <?php echo $_SESSION['myusername']; ?></h2>
<h2 align="center">Add Bazzer Date</h2>
 <form align="center" action = "" method = "post">
                  <label>UserName  :</label><input type = "text" name = "username" required/><br /><br />
                  <label>1st Date  :</label><input type = "date" name = "date1"required /><br/><br />
				  <label>2nd Date  :</label><input type = "date" name = "date2" required/><br /><br />
				  <label>3rd Date  :</label><input type = "date" name = "date3"required /><br /><br />
                  <input type = "submit" value = " Submit "/><br />
               </form>
</body>
</html>
