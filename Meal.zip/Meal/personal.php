<?php
include("Config.php");
   session_start();
   ?>
<!DOCTYPE html >
<html >
<head>
<link rel="stylesheet" href="style.css">
<title>Untitled Document</title>
</head>

<body bgcolor="#9999FF">
<h1 align="center" >Meal Mangment  System</h1>
<ul>
<li><a href="Memberpage.php"><h3>My Page</h3></a></li>
<li><a href="personal.php"><h3> Show My Info</h3></a></li>
 <li><a href="addmeal.php"><h3>Next Day Meal</h3></a></li>
 <li><a href="Showdate.php"><h3>Show My Bazzer Date</h3></a></li>
 <li><a href="Logout.php"><h3>Logout</h3></a></li>
 </ul>

</body>
</html>
<?php
include("Config.php");
   //session_start();
$sql = "SELECT SUM(pcost) AS value_sum FROM cost";
$result = mysqli_query($db,$sql);

if ($result->num_rows > 0) {
    
    while($row = $result->fetch_assoc()) {
        
		$b=$row["value_sum"];
    }
} else {
    echo "0 results";
}

$sql = "SELECT SUM(tmeal) AS value_sum1 FROM meal";
$result = mysqli_query($db,$sql);

if ($result->num_rows > 0) {
   
    while($row = $result->fetch_assoc()) {
        
		$m=$row["value_sum1"];
    }
} else {
    echo "0 results";
}

$mrate=$b/$m;
echo "meal rate :".$mrate;
echo "<br>";

$N=$_SESSION['myusername'];
$sql = "SELECT SUM(dposit) AS value_sum  FROM blance WHERE username='$N'";
$result = mysqli_query($db,$sql);

if ($result->num_rows > 0) {
    
    while($row = $result->fetch_assoc()) {
        echo "Total Deposit : " . $row["value_sum"];
		echo "<br>";
		$deposit=$row["value_sum"];
    }
} else {
    echo "0 results";
}

$sql = "SELECT SUM(tmeal) AS value_sum1  FROM meal WHERE username='$N'";
$result = mysqli_query($db,$sql);

if ($result->num_rows > 0) {
    
    while($row = $result->fetch_assoc()) {
        echo "Total Meal : " . $row["value_sum1"];
		echo "<br>";
		$Meal=$row["value_sum1"];
    }
} else {
    echo "0 results";
}
$Cost=$mrate*$Meal;
$curntBlans=$deposit-$Cost;
echo "Total Cost:".$Cost;
echo "<br>";
echo "Curent Blance:".$curntBlans;
?>