<?php
   include("Config.php");
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {   
      $myusername = mysqli_real_escape_string($db,$_POST['username']);
      $mypassword = mysqli_real_escape_string($db,$_POST['password']); 
      
      $sql = "SELECT * FROM member WHERE username = '$myusername' and passcode = '$mypassword'";
      $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $active = $row['active'];
     
      $count = mysqli_num_rows($result);
	
      if($count == 1) 
	  {
	      
           $sql = "SELECT SUM(pcost) AS value_sum FROM cost";
            $result = mysqli_query($db,$sql);

           if ($result->num_rows > 0)
		   {
        while($row = $result->fetch_assoc()) 
	   {
		$b=$row["value_sum"];
    }
          } else
		   {
    echo "0 results";

           }

          $sql = "SELECT SUM(tmeal) AS value_sum1 FROM meal";
           $result = mysqli_query($db,$sql);

          if ($result->num_rows > 0) 
		   {
    
    while($row = $result->fetch_assoc()) 
	{
		$m=$row["value_sum1"];
    }
}  
else 
{
    echo "0 results";
}

$mrate=$b/$m;
$N=$myusername;
$sql = "SELECT SUM(dposit) AS value_sum2  FROM blance WHERE username='$N'";
$result = mysqli_query($db,$sql);

if ($result->num_rows > 0) {
    
    while($row = $result->fetch_assoc()) {
		$deposit=$row["value_sum2"];
    }
} else {
    echo "0 results";
}

$sql = "SELECT SUM(tmeal) AS value_sum1  FROM meal WHERE username='$N'";
$result = mysqli_query($db,$sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
		$Meal=$row["value_sum1"];
    }
} else {
    echo "0 results";
}
$Cost=$mrate*$Meal;
$curntBlans=$deposit-$Cost; 
	  if($curntBlans>1)
	    {
         session_register("myusername");
         $_SESSION['login_user'] = $myusername;
         header("location: Memberpage.php");
		 }
		 else{
		 echo "You Blance Is Not Insufficient";
		 }
        }
	  else {
         echo "Your Login Name or Password is invalid";
      }
   }
?>

<!DOCTYPE html >
<html >
<head>
<title>Untitled Document</title>
<link rel="stylesheet" href="style.css">
</head>

<body bgcolor="#666633">
<h1 align="center" >Meal Mangment  System</h1>
<ul>
<li><a href=index.php> <h3 > Home</h3></a></li>
<li><a href=Member.php> <h3 > Login As Mess Member</h3></a></li>
<li><a href=Manger.php><h3 >Login As Mess Menagers</h3></a></li>
<li><a href=Bua.php><h3> Login As Bua</h3></a></li>
</ul>
<h2 align="center" >Login As Members</h2>
 <form  align="center"  action = "" method = "post">
                  <label>UserName  :</label><input type = "text" name = "username" class = "box" required/><br /><br />
                  <label>Password  :</label><input type = "password" name = "password" class = "box"  required/><br/><br />
                  <input type = "submit" value = " Submit "/><br />
               </form>
			   <a href="reg.php"><h3 align="center" > If You are new Member sing up frist </h3></a>
</body>
</html>
