<?php
include("Config.php");
   if($_SERVER["REQUEST_METHOD"] == "POST") 
   {
      $myusername = mysqli_real_escape_string($db,$_POST['username']); 
	  $myname = mysqli_real_escape_string($db,$_POST['name']);
	  $mypass = mysqli_real_escape_string($db,$_POST['passcode']);
	 $sql = "INSERT INTO member (username,passcode)VALUES ('$myusername', '$mypass')"; 
	 
	 if ($db->query($sql) === TRUE)
    {
     header("location:Member.php");
    } 
else {
     echo "User name Exist";
     
     }
	  
}

?>
<!DOCTYPE html >
<html >
<head>
<link rel="stylesheet" href="style.css">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>

<body bgcolor="#006666">

<ul>
<li><a href="Memberpage.php"><h3>My Page</h3></a></li>
<li><a href="personal.php"><h3> Show My Info</h3></a></li>
 <li><a href="addmeal.php"><h3>Next Day Meal</h3></a></li>
 <li><a href="Showdate.php"><h3>Show My Bazzer Date</h3></a></li>
 <li><a href="Logout.php"><h3>Logout</h3></a></li>
 
 </ul>
 <h1 align="center" >Meal Mangment  System</h1>
 <table>
 <tr>
 <td colspan="2"><h2>Create a new account</h2></td>
 </tr>
<form action = "" method = "post">
<tr>
                  <td>UserName  :</td><td><input type = "text" name = "username" class = "box" required /></td>
				  </tr>
                  <tr>
				  <td>Name  :</td><td><input type = "text" name = "name" class = "box"  required/></td>
				  </tr>
				  <tr>
				  <td>password  :</td><td><input type = "password" name = "passcode" class = "box"required/></td>
                  </tr>
				  <tr><td><input type = "submit" value = " Submit "/></td></tr>
               </form>
			   </table>
</body>
</html>
