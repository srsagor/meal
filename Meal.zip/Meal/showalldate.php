<?php
include("Config.php");
   session_start();
   ?>
<!DOCTYPE html >
<html>
<head>
<link rel="stylesheet" href="style.css">
<title>Show Bazzer Date</title>
</head>

<body bgcolor="#00CCFF">
<h1 align="center" >Meal Mangment  System</h1>
<ul>
<li><a href="mangerpage.php"><h3> My Page</h3></a></li>
<li><a href="bazzercost.php"><h3> Add Bazzar Cost</h3></a></li>
<li><a href="Deposit.php"><h3> Deposit</h3></a></li>
<li><a href="addbazzerdate.php"><h3> Add Bazzer Date</h3></a></li>
<li><a href="showalldate.php"><h3> Show Bazzer Date</h3></a></li>
<li><a href="Logout.php"><h3>Logout</h3></a></li>
</ul>
<p>Welcome <?php echo $_SESSION['myusername']; ?>!</p>

</body>
</html>
<?php
include("Config.php");
$sql = "SELECT username, Date1, Date2, Date3 FROM blist";
$result = $db->query($sql);

echo "<table border='1'>
<tr>
<th>User Name</th>
<th>Date1</th>
<th>Date2</th>
<th>Date3</th>
</tr>";

while($row = mysqli_fetch_array($result))
{
echo "<tr>";
echo "<td>" . $row['username'] . "</td>";
echo "<td>" . $row['Date1'] . "</td>";
echo "<td>" . $row['Date2'] . "</td>";
echo "<td>" . $row['Date3'] . "</td>";
echo "</tr>";
}
echo "</table>";

?> 