<!DOCTYPE html >
<html>
<head>
<title>Home</title>
 <link rel="stylesheet" href="style.css">

</head>

<body bgcolor="#006666" >
<h1 align="center" >Meal Mangment  System</h1>
<ul>
<li><a href=index.php> <h3 > Home</h3></a></li>
<li><a href=Member.php> <h3 > Login As Mess Member</h3></a></li>
<li><a href=Manger.php><h3 >Login As Mess Menagers</h3></a></li>
<li><a href=Bua.php><h3> Login As Bua</h3></a></li>
</ul>
</body>
</html>
