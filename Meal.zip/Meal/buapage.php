<?php
include("Config.php");
   session_start();
   ?>
<html>
<head>
<link rel="stylesheet" href="style.css">
</head>
<body bgcolor="#0099FF">
<h1 align="center" >Meal Mangment  System</h1>
<ul>
<li><a href="buapage.php"><h3> My Page</h3></a></li>
<li><a href="Logout.php"><h3> Logout</h3></a></li>

</ul>
<h2 align="center">Show today Meal</h2>
<form align="center" action = "" method = "post">
              
                  <label>Date  :</label><input type = "date" name = "date1" required/><br/>
                  <input type = "submit" value = " Submit "/><br />
               </form>
</body>
<?php
include("Config.php");
if($_SERVER["REQUEST_METHOD"] == "POST") 
   {
   $mydate = mysqli_real_escape_string($db,$_POST['date1']);
$sql = "SELECT username, bfast, luns, dnr FROM meal WHERE Date='$mydate'";
$result = $db->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "Name: " . $row["username"]. " Sokal: " . $row["bfast"]. "Dupur:" . $row["luns"]."Rat:" .$row["dnr"]. "<br>";
    }
} else {
    echo "0 results";
}
$sql = "SELECT SUM(tmeal) AS value_sum1 FROM meal WHERE Date='$mydate'";
$result = mysqli_query($db,$sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "Total meal : " . $row["value_sum1"];
    }
} else {
    echo "0 results";
}
}
?>