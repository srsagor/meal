<?php
include("Config.php");
   session_start();
   ?>
   
<!DOCTYPE html >
<html >
<head>
<title>Untitled Document</title>
<link rel="stylesheet" href="style.css">
</head>

<body bgcolor="#336666">
<h1 align="center">Meal Mangment  System</h1>
<ul>
<li><a href="Memberpage.php"><h3>My Page</h3></a></li>
<li><a href="personal.php"><h3> Show My Info</h3></a></li>
 <li><a href="addmeal.php"><h3>Next Day Meal</h3></a></li>
 <li><a href="Showdate.php"><h3>Show My Bazzer Date</h3></a></li>
 <li><a href="Logout.php"><h3>Logout</h3></a></li>
 </ul>
<h2>Welcome <?php echo $_SESSION['myusername']; ?></h2>
</body>
</html>
<?php
include("Config.php");
   session_start();
   $N=$_SESSION['myusername'];
   $sql = "SELECT username, Date1, Date2, Date3 FROM blist WHERE username='$N'";
$result = $db->query($sql);

echo "<table border='1'>
<tr>
<th>User Name</th>
<th>Date1</th>
<th>Date2</th>
<th>Date3</th>
</tr>";

while($row = mysqli_fetch_array($result))
{
echo "<tr>";
echo "<td>" . $row['username'] . "</td>";
echo "<td>" . $row['Date1'] . "</td>";
echo "<td>" . $row['Date2'] . "</td>";
echo "<td>" . $row['Date3'] . "</td>";
echo "</tr>";
}
echo "</table>";

?> 