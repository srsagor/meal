<?php
include("Config.php");
   session_start();
   ?>
<!DOCTYPE html >
<html >
<head>
<title>Untitled Document</title>
 <link rel="stylesheet" href="style.css">
</head>

<body bgcolor="#00CCFF">
<h1 align="center" >Meal Mangment  System</h1>
<ul>
<li><a href="mangerpage.php"><h3> My Page</h3></a></li>
<li><a href="bazzercost.php"><h3> Add Bazzar Cost</h3></a></li>
<li><a href="Deposit.php"><h3> Deposit</h3></a></li>
<li><a href="addbazzerdate.php"><h3> Add Bazzer Date</h3></a></li>
<li><a href="showalldate.php"><h3> Show Bazzer Date</h3></a></li>
<li><a href="Logout.php"><h3>Logout</h3></a></li>
</ul>
<p>Welcome <?php echo $_SESSION['myusername']; ?>!</p>
</body>
</html>

<?php
include("Config.php");
   //session_start();
$sql = "SELECT SUM(pcost) AS value_sum FROM cost";
$result = mysqli_query($db,$sql);

if ($result->num_rows > 0) {
    
    while($row = $result->fetch_assoc()) {
        echo "Total Bazzer : " . $row["value_sum"];
		echo "<br>";
		$b=$row["value_sum"];
    }
} else {
    echo "0 results";
}

$sql = "SELECT SUM(tmeal) AS value_sum1 FROM meal";
$result = mysqli_query($db,$sql);

if ($result->num_rows > 0) {
   
    while($row = $result->fetch_assoc()) {
        echo "Total meal : " . $row["value_sum1"];
		echo "<br>";
		$m=$row["value_sum1"];
    }
} else {
    echo "0 results";
}

$mrate=$b/$m;
echo "meal rate :".$mrate;
echo "<br>";


$sql = "SELECT SUM(dposit) AS value_sum FROM blance";
$result = mysqli_query($db,$sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "Total Deposit : " . $row["value_sum"];
		echo "<br>";
		$d=$row["value_sum"];
    }
} else {
    echo "0 results";
}
$blns=$d-$b;
echo "Current Blance :".$blns;
echo "<br>";
?>
