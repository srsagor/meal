-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 18, 2017 at 04:10 AM
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `database`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `username` varchar(50) NOT NULL,
  `passcode` int(11) NOT NULL,
  `userid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `passcode`, `userid`) VALUES
('srs007', 1234, 123);

-- --------------------------------------------------------

--
-- Table structure for table `blance`
--

CREATE TABLE IF NOT EXISTS `blance` (
  `username` varchar(50) NOT NULL,
  `dposit` int(11) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blance`
--

INSERT INTO `blance` (`username`, `dposit`) VALUES
('tanvir', 1000),
('soyon', 1000),
('sagor', 6500),
('amit', 2000),
('utsab', 1424),
('anayet', 500);

-- --------------------------------------------------------

--
-- Table structure for table `blist`
--

CREATE TABLE IF NOT EXISTS `blist` (
  `username` varchar(50) NOT NULL,
  `Date1` date NOT NULL,
  `Date2` date NOT NULL,
  `Date3` date NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `blist`
--

INSERT INTO `blist` (`username`, `Date1`, `Date2`, `Date3`) VALUES
('tanvir', '2017-07-18', '2017-07-20', '2017-07-26'),
('sagor', '2017-07-02', '2017-07-01', '2017-07-03'),
('anik', '2017-07-31', '2017-07-30', '2017-07-29');

-- --------------------------------------------------------

--
-- Table structure for table `bua`
--

CREATE TABLE IF NOT EXISTS `bua` (
  `username` varchar(50) NOT NULL,
  `passcode` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bua`
--

INSERT INTO `bua` (`username`, `passcode`) VALUES
('Bua', 123456);

-- --------------------------------------------------------

--
-- Table structure for table `cost`
--

CREATE TABLE IF NOT EXISTS `cost` (
  `Date` date NOT NULL,
  `pcost` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cost`
--

INSERT INTO `cost` (`Date`, `pcost`) VALUES
('2017-07-10', 448),
('2017-07-09', 475),
('2017-07-06', 572),
('2017-07-08', 700),
('2017-07-07', 400),
('2017-07-05', 510),
('2017-07-04', 770);

-- --------------------------------------------------------

--
-- Table structure for table `meal`
--

CREATE TABLE IF NOT EXISTS `meal` (
  `Date` date NOT NULL,
  `username` varchar(50) NOT NULL,
  `bfast` int(11) NOT NULL,
  `luns` int(11) NOT NULL,
  `dnr` int(11) NOT NULL,
  `tmeal` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `meal`
--

INSERT INTO `meal` (`Date`, `username`, `bfast`, `luns`, `dnr`, `tmeal`) VALUES
('2017-07-04', 'tuhin', 4, 4, 4, 12),
('2017-07-04', 'utsab', 4, 4, 4, 12),
('2017-07-05', 'amit', 4, 1, 0, 5),
('2017-07-05', 'sagor', 2, 0, 0, 2),
('2017-07-04', 'amit', 4, 4, 4, 12),
('2017-07-04', 'sagor', 4, 4, 4, 12),
('2017-07-05', 'tuhin', 1, 0, 0, 1),
('2017-07-04', 'mahin', 4, 4, 4, 12),
('2017-07-05', 'mahin', 4, 2, 0, 6),
('2017-07-04', 'anayet', 4, 4, 2, 10),
('2017-07-04', 'tanvir', 4, 4, 4, 12),
('2017-07-05', 'tanvir', 4, 2, 0, 6),
('2017-07-04', 'soyon', 4, 4, 4, 12),
('2017-07-05', 'soyon', 3, 0, 0, 3),
('2017-07-05', 'rokib', 4, 4, 4, 12),
('2017-07-06', 'rokib', 2, 0, 0, 2),
('2017-10-07', 'sagor', 1, 1, 1, 3),
('2017-11-09', 'sagor', 1, 1, 1, 3),
('2017-07-17', 'sagor', 1, 1, 1, 3),
('2017-07-17', 'mahin', 1, 1, 1, 3),
('2017-07-17', 'sagor', 1, 2, 1, 4),
('2017-07-19', 'sagor', 1, 1, 1, 3);

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE IF NOT EXISTS `member` (
  `username` varchar(50) NOT NULL,
  `passcode` int(11) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`username`, `passcode`) VALUES
('sagor', 1234),
('utsab', 1234),
('amit', 123456),
('tanvir', 1234),
('soyon', 1234),
('anayet', 1234),
('mahin', 1234),
('tuhin', 1234),
('rokib', 1234),
('dipto', 1234),
('sagor1', 1234);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
