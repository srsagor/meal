<?php
include("Config.php");
   session_start();
   ?>
<!DOCTYPE html >
<html >
<head>
<title>Untitled Document</title>
<link rel="stylesheet" href="style.css">
</head>

<body bgcolor="#336666">
<h1 align="center">Meal Mangment  System</h1>
<ul>
<li><a href="Memberpage.php"><h3>My Page</h3></a></li>
<li><a href="personal.php"><h3> Show My Info</h3></a></li>
 <li><a href="addmeal.php"><h3>Next Day Meal</h3></a></li>
 <li><a href="Showdate.php"><h3>Show My Bazzer Date</h3></a></li>
 <li><a href="Logout.php"><h3>Logout</h3></a></li>
 </ul>
<h2>Welcome <?php echo $_SESSION['myusername']; ?></h2>
</body>
</html>
