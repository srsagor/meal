<?php
include("Config.php");
   session_start();
   if($_SERVER["REQUEST_METHOD"] == "POST") 
   {
      $mydate = mysqli_real_escape_string($db,$_POST['date']); 
	  $mycost = mysqli_real_escape_string($db,$_POST['pcost']);
	  
	 $sql = "INSERT INTO cost (Date, pcost)VALUES ('$mydate', '$mycost')"; 
	 
	 if ($db->query($sql) === TRUE) {
    header("location: mangerpage.php");
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}
	  
}

?>
<!DOCTYPE html>
<html>
<head>
<title>Untitled Document</title>
<link rel="stylesheet" href="style.css">
</head>

<body bgcolor="#00FFFF">

<h1 align="center" >Meal Mangment  System</h1>
<ul>
<li><a href="mangerpage.php"><h3> My Page</h3></a></li>
<li><a href="bazzercost.php"><h3> Add Bazzar Cost</h3></a></li>
<li><a href="Deposit.php"><h3> Deposit</h3></a></li>
<li><a href="addbazzerdate.php"><h3> Add Bazzer Date</h3></a></li>
<li><a href="showalldate.php"><h3> Show Bazzer Date</h3></a></li>
<li><a href="Logout.php"><h3>Logout</h3></a></li>
</ul>
<p>Welcome <?php echo $_SESSION['myusername']; ?></p>
<h2 align="center">Per Day Bazzer Cost</h2>
 <form  align="center" action = "" method = "post">
                  <label>UserName  :</label><input type = "text" name = "username" class = "box" required/><br /><br />
                  <label>Date  :</label><input type = "date" name = "date" class = "box" required/><br/><br />
				  <label>Bazzer cost  :</label><input type = "text" name = "pcost" class = "box"required/><br /><br />
                  <input type = "submit" value = " Submit "/><br />
               </form>


</body>
</html>
