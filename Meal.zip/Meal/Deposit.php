<?php
include("Config.php");
   session_start();
   if($_SERVER["REQUEST_METHOD"] == "POST") 
   {
      $myusername = mysqli_real_escape_string($db,$_POST['username']); 
	  $mycost = mysqli_real_escape_string($db,$_POST['dposit']);
	   $sql = "SELECT * FROM member WHERE username = '$myusername'";
	   $result = mysqli_query($db,$sql);
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $active = $row['active'];
     
      $count = mysqli_num_rows($result);
      
		
      if($count == 1) {
	  $sql = "SELECT SUM(dposit) AS value_sum FROM blance WHERE username='$myusername'";
      $result = mysqli_query($db,$sql);

if ($result->num_rows > 0)
 {
    while($row = $result->fetch_assoc())
	 {
       
      $a=$row["value_sum"];
	  }
	  $add=$a+$mycost;
	$sql = "UPDATE blance SET dposit='$add' WHERE username='$myusername'";

if ($db->query($sql) === TRUE)
 {
    header("location: mangerpage.php");
 } 
else
 {
    echo "Error updating record";
  }
} 
else
 {
   
 }

	 $sql = "INSERT INTO blance (username,dposit)VALUES ('$myusername', '$mycost')"; 
	 if ($db->query($sql) === TRUE) 
	 
	 {
    header("location: mangerpage.php");
     } 
   else 
   {
    echo "Error: ";
   }
   }
   else
	   {
         echo "Your User Name is Not Registers";
      }
     
}

?>
<!DOCTYPE html>
<html>
<head>
<title>Untitled Document</title>
<link rel="stylesheet" href="style.css">
</head>

<body bgcolor="#336633">
<h1 align="center" >Meal Mangment  System</h1>
<ul>
<li><a href="mangerpage.php"><h3> My Page</h3></a></li>
<li><a href="bazzercost.php"><h3> Add Bazzar Cost</h3></a></li>
<li><a href="Deposit.php"><h3> Deposit</h3></a></li>
<li><a href="addbazzerdate.php"><h3> Add Bazzer Date</h3></a></li>
<li><a href="showalldate.php"><h3> Show Bazzer Date</h3></a></li>
<li><a href="Logout.php"><h3>Logout</h3></a></li>
</ul>
<p>Welcome <?php echo $_SESSION['myusername']; ?></p>
<h2 align="center">Add Deposit</h2>
 <form  align="center" action = "" method = "post">
                  <label>UserName  :</label><input type = "text" name = "username" class = "box"required/><br /><br />
				  <label>Add deposit  :</label><input type = "text" name = "dposit" class = "box"required/><br /><br />
                  <input type = "submit" value = " Submit "/><br />
               </form>


</body>
</html>

